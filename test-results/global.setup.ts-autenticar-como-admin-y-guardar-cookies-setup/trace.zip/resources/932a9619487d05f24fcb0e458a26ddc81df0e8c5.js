(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0q79z23._.js","static/chunks/node_modules_@base-ui_react_esm_1trxrti._.js","static/chunks/node_modules_11a9z23._.js","static/chunks/src_0p_0469._.js"],
    source: "dynamic"
});
